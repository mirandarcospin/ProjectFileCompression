/*  Program: Huffman Compression File
 *  Author : Miranda Ramirez Cospin
 *  Date   : 11/30/20 Fall 2020
 *  Course : CS375 Software Engineering II
 *  Compile: javac SchubsH.java
 *  Execute: java SchubsH
 *  Note   : Project File Compression using Huffman
 */

import java.io.IOException;
import java.io.File;

public class SchubsH {

  private static final int R = 256;

  private static class Node implements Comparable<Node>
  {
    private final char ch;
    private final int freq;
    private final Node left, right;

    Node(char ch, int freq, Node left, Node right)
    {
      this.ch    = ch;
      this.freq  = freq;
      this.left  = left;
      this.right = right;
    }

    // is the node a leaf node?
    private boolean isLeaf()
    {
      assert ((left == null) && (right == null)) || ((left != null) && (right != null));
      return (left == null) && (right == null);
    }

    // compare, based on frequency
    public int compareTo(Node that)
    {
      return this.freq - that.freq;
    }
  }

  public static void compress(BinaryIn in, BinaryOut out)
  {
    // read the input
    String s = in.readString();
    char[] input = s.toCharArray();

    // tabulate frequency counts
    int[] freq = new int[R];
    for (int i = 0; i < input.length; i++)
    {
      freq[input[i]]++;
    }

    // build Huffman trie
    Node root = buildTrie(freq);

    // build code table
    String[] st = new String[R];
    buildCode(st, root, "");

    // print trie for decoder
    writeTrie(root);

    // print number of bytes in original uncompressed message
    out.write(input.length);

    // use Huffman code to encode input
    for (int i = 0; i < input.length; i++)
    {
      String code = st[input[i]];
      for (int j = 0; j < code.length(); j++)
      {
        if (code.charAt(j) == '0')
        {
          out.write(false);
        }
        else if (code.charAt(j) == '1')
        {
          out.write(true);
        }
        else
          throw new IllegalStateException("Illegal state");
      }
    }
    // close output stream
    out.close();
  }

  // build the Huffman trie given frequencies
  private static Node buildTrie(int[] freq)
  {
    // initialze priority queue with singleton trees
    MinPQ<Node> pq = new MinPQ<Node>();
    for (char c = 0; c < R; c++)
    {
      if (freq[c] > 0)
        pq.insert(new Node(c, freq[c], null, null));
    }
    // merge two smallest trees
    while (pq.size() > 1)
    {
      Node left  = pq.delMin();
      Node right = pq.delMin();
      Node parent = new Node('\0', left.freq + right.freq, left, right);
      pq.insert(parent);
    }
    return pq.delMin();
  }

  // write bitstring-encoded trie to standard output
  private static void writeTrie(Node x)
  {
    if (x.isLeaf())
    {
      BinaryStdOut.write(true);
      BinaryStdOut.write(x.ch, 8);
      return;
    }
    BinaryStdOut.write(false);
    writeTrie(x.left);
    writeTrie(x.right);
  }

  // make a lookup table from symbols and their encodings
  private static void buildCode(String[] st, Node x, String s)
  {
    if (!x.isLeaf())
    {
      buildCode(st, x.left,  s + '0');
      buildCode(st, x.right, s + '1');
    }
    else
    {
      st[x.ch] = s;
    }
  }

  public static void HuffmanMain(String[] args)
  {
    BinaryIn in = null;
    BinaryOut out = null;
    String path = "src" + File.separator + "files" + File.separator;
    File thisFile;
    String file = "";
    String fileType = "";

    for(int i = 0; i < args.length; i++)
    {
      for(int m = args[i].length()-3; m < args[i].length(); m++)
      {

        fileType += args[i].charAt(m);

        try
        {
          thisFile = new File(path + args[i]);

          if(fileType.equals(".zh"))
          {
            for(int j = 0; j < args[i].length()-3; j++)
            {
              file += args[i].charAt(j);
            }
            in = new BinaryIn(args[i]);
            out = new BinaryOut(file + ".zh");
            compress(in, out);
          }
          else
          {
            in = new BinaryIn(args[i]);
            out = new BinaryOut(args[i] + ".hh");
            compress(in, out);
          }
        }
        finally
        {
          if(out != null)
          {
            out.close();
          }
        }
      }
    }
  }

}
