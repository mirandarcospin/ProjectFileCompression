/*  Program: Decompression File
 *  Author : Miranda Ramirez Cospin
 *  Date   : 11/30/20 Fall 2020
 *  Course : CS375 Software Engineering II
 *  Compile: javac Deschubs.java
 *  Execute: java Deschubs
 *  Note   : Project File Decompression for HUffman, LZW, and Untars
 */

import java.io.IOException;
import java.io.File;

public class Deschubs {

  //private static final int HuffmanR = 256;

  private static class Node implements Comparable<Node>
  {
    private final char ch;
    private final int freq;
    private final Node left, right;

    Node(char ch, int freq, Node left, Node right)
    {
      this.ch    = ch;
      this.freq  = freq;
      this.left  = left;
      this.right = right;
    }

    // is the node a leaf node?
    private boolean isLeaf()
    {
      assert ((left == null) && (right == null)) || ((left != null) && (right != null));
      return (left == null) && (right == null);
    }

    // compare, based on frequency
    public int compareTo(Node that)
    {
      return this.freq - that.freq;
    }
  }

  public static void HuffmanExpand(BinaryIn in, BinaryOut out)
  {
    // read in Huffman trie from input stream
    Node root = readTrie();

    // number of bytes to write
    int length = in.readInt();

    // decode using the Huffman trie
    for (int i = 0; i < length; i++)
    {
      Node x = root;
      while (!x.isLeaf())
      {
        boolean bit = in.readBoolean();
        if(bit)
          x = x.right;
        else
          x = x.left;
      }
      out.write(x.ch, 8);
    }
    out.close();
  }

  private static Node readTrie()
  {
    boolean isLeaf = BinaryStdIn.readBoolean();
    if (isLeaf)
    {
      return new Node(BinaryStdIn.readChar(), -1, null, null);
    }
    else
    {
      return new Node('\0', -1, readTrie(), readTrie());
    }
  }

  private static final int R = 256;        // number of input chars
  private static final int L = 4096;       // number of codewords = 2^W
  private static final int W = 12;         // codeword width

  public static void LZWExpand(BinaryIn in, BinaryOut out)
  {
    String[] st = new String[L];
    int i; // next available codeword value

    // initialize symbol table with all 1-character strings
    for (i = 0; i < R; i++)
      st[i] = "" + (char) i;
    st[i++] = "";                        // (unused) lookahead for EOF

    int codeword = in.readInt(W);
    String val = st[codeword];

    while (true)
    {
      out.write(val);
      codeword = in.readInt(W);

      if (codeword == R)
        break;
      String s = st[codeword];

      if (i == codeword)
        s = val + val.charAt(0);   // special case hack

      if (i < L)
        st[i++] = val + s.charAt(0);

      val = s;
    }
    out.close();
  }

  public static void TarsExpand(BinaryIn in1, BinaryOut out1) 
  {
  	BinaryIn in = in1;
  	BinaryOut out = out1;

  	char sep =  (char) 255;  // all ones 11111111

  	// nerf through archive, extracting files
  	// int lengthoffilename, sep, filename, sep, lengthoffile, sep, bits
    //in = new BinaryIn(args[0]);

    while(! in.isEmpty()){
      try {
        int filenamesize = in.readInt();
        sep = in.readChar();
        String filename="";
        for(int i = 0; i < filenamesize; i++)
          filename += in.readChar();

        sep = in.readChar();
        long filesize = in.readLong();
        sep = in.readChar();
        System.out.println("Extracting file: " + filename + " ("+ filesize +").");
        out = new BinaryOut(filename);
        for(int i = 0; i < filesize; i++)
          out.write(in.readChar());

      } finally {
        if (out != null)
        out.close();
      }
    }
  }


  public static void UncompressMain(String[] args)
  {
    BinaryIn in = null;
    BinaryOut out = null;
    String path = "src" + File.separator + "files" + File.separator;
    File thisFile;
    String file = "";
    String fileType = "";

    for(int i = 0; i < args.length; i++)
    {
      for(int m = args[i].length()-3; m < args[i].length(); m++)
      {

        fileType += args[i].charAt(m);

        try
        {
          thisFile = new File(path + args[i]);

          if(fileType.equals(".zh"))
          {
            for(int j = 0; j < args[i].length()-3; j++)
            {
              file += args[i].charAt(j);
            }
            in = new BinaryIn(args[i]);
            out = new BinaryOut(file);
            TarsExpand(in, out);
          }
          else if(fileType.equals(".zl"))
          {
            for(int j = 0; j < args[i].length()-3; j++)
            {
              file += args[i].charAt(j);
            }
            in = new BinaryIn(args[i]);
            out = new BinaryOut(file);
            TarsExpand(in, out);
          }
          else if(fileType.equals(".hh"))
          {
            in = new BinaryIn(args[i]);
            out = new BinaryOut(args[i]);
            HuffmanExpand(in, out);
          }
          else if(fileType.equals(".ll"))
          {
            in = new BinaryIn(args[i]);
            out = new BinaryOut(args[i]);
            LZWExpand(in, out);
          }
        }
        finally
        {
          if(out != null)
          {
            out.close();
          }
        }
      }
    }
  }











}
