/*  Program: Tars Compression File
 *  Author : Miranda Ramirez Cospin
 *  Date   : 11/30/20 Fall 2020
 *  Course : CS375 Software Engineering II
 *  Compile: javac SchubsArc.java
 *  Execute: java SchubsArc
 *  Note   : Project File Compression using Tars
 */

import java.io.IOException;
import java.io.File;

public class SchubsArc {

  static Boolean exists = true;
  static Boolean fileIsFile = true;

  static void tarsnMain(String filename, String outName, BinaryOut out)
  {
	  char separator = (char) 255;  // all ones 11111111

	  try
    {
      File in1 = new File(filename);
      if (!in1.exists() || !in1.isFile())
      {
        if(!in1.exists())
          exists = false;
        if(!in1.isFile())
          fileIsFile = false;
        return;
      }

      long filesize = in1.length();
      int filenamesize = filename.length();

      out.write(filenamesize);
      out.write(separator);

      out.write(filename);
      out.write(separator);

      out.write(filesize);
      out.write(separator);

      System.out.println("archive " + outName);
      System.out.println("adding file " + filename + "[" + filesize + "]");
      BinaryIn bin1 = new BinaryIn(filename);
      while(! bin1.isEmpty())
      {
        out.write(bin1.readChar());
      }
	  } catch(RuntimeException ex) {
      System.out.println(ex.toString());
      System.out.println("File not found " + filename);
    }
    if(out != null)
      out.close();
  }

  public static void TarsMain(String[] args)
  {
    BinaryIn in = null;
    BinaryOut out = new BinaryOut(args[0]);
    int size = args.length;
    String path = "src" + File.separator + "files" + File.separator;
    File thisFile;
    String file = "";
    String fileType = "";

    for(int i = 0; i < args.length; i++)
    {
      for(int m = args[i].length()-3; m < args[i].length(); m++)
      {
        fileType += args[i].charAt(m);

        try
        {
          thisFile = new File(path + args[i]);

          if(fileType.equals(".zh"))
          {
            for(int j = 0; j < args[i].length()-3; j++)
            {
              file += args[i].charAt(j);
            }
            in = new BinaryIn(args[i]);
            out = new BinaryOut(file + ".tar");
            SchubsH.compress(in, out);
          }
          else
          {
            in = new BinaryIn(args[i]);
            out = new BinaryOut(args[i] + ".tar");
            tarsnMain(args[i], args[0], out); //compress(in, out);
          }
        } finally {
          if(out != null)
          out.close();
        }
      }
    }

  }

  public static Boolean getExists() { return exists; }

  public static Boolean getIsFile() { return fileIsFile; }

}
