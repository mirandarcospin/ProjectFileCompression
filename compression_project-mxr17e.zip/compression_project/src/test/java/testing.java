/*  Program: Testing
 *  Author : Miranda Ramirez Cospin
 *  Date   : 11/30/20 Fall 2020
 *  Course : CS375 Software Engineering II
 *  Compile: mvn compile
 *  Execute: mvn test
 *  Note   : Project File Compression using Huffman
 */

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.util.Random;
import java.io.IOException;

public class testing {

  String path = "src" + File.separator + "files" + File.separator;

/******************************************************************************/

  public void huffmanTest(String file) throws IOException
  {
    SchubsH.HuffmanMain(new String[] { file });
  }
  @Test
  public void compressHuffmanTest() throws IOException
  {
    String file1 = path + "test1.txt";
    huffmanTest(file1);
  }

/******************************************************************************/

  public void lzwTest(String file) throws IOException
  {
    SchubsL.LZWMain(new String[] { file });
  }
  @Test
  public void compressLZWTest() throws IOException
  {
    String file1 = path + "test2.txt";
    lzwTest(file1);
  }

/******************************************************************************/

  public void huffmanTest2(String file) throws IOException
  {
    Deschubs.UncompressMain(new String[] { file });
  }
  @Test
  public void decompressHuffmanTest() throws IOException
  {
    String file1 = path + "test1.txt.hh";
    huffmanTest2(file1);
  }

/******************************************************************************/

  public void LZWTest2(String file) throws IOException
  {
    Deschubs.UncompressMain(new String[] { file });
  }
  @Test
  public void decompressLZWTest() throws IOException
  {
    String file1 = path + "test1.txt.ll";
    LZWTest2(file1);
  }

/******************************************************************************/

  public void tarsTest(String archive, String file, String file2) throws IOException
  {
    SchubsArc.TarsMain(new String[] { archive, file, file2 });
  }
  @Test
  public void compressTarsTest() throws IOException
  {
    String archive = path + "blee.tar";
    String file = path + "test1.txt";
    String file2 = path + "test1_2.txt";
    tarsTest(archive, file, file2);
  }

/******************************************************************************/

  public void fileEmptyTest(String file) throws IOException
  {
    String in = path + file;
    FileInputStream in1 = null;
    int c1;
    try
    {
      in1 = new FileInputStream(in);
      c1 = in1.read();
    }
    finally
    {
      if(in1 != null)
      {
        in1.close();
        System.out.println("File is not empty");
      }
      else
      {
        System.out.println("File empty");
      }
    }
  }

  @Test
  public void passFileName() throws IOException
  {
    String in = "test1.txt";
    fileEmptyTest(in);
  }

  @Test
  public void fileExistsTest() throws IOException
  {
    if(!(SchubsArc.getExists()))
      System.out.println("The file does not exists");
    else
      System.out.println("The file already exists");
  }

  @Test
  public void destinationFileExistsTest() throws IOException
  {
    File inputFile = new File(path + "text1.txt");
    File outputFile = new File(path + "text2.txt");

    String[] files = inputFile.list();
    String[] files2 = outputFile.list();

    if(files == files2)
      System.out.println("The destination file already exists");
    else
      System.out.println("The destination file does not exists");
  }

  @Test
  public void fileToBeTarsTest() throws IOException
  {
    if(!(SchubsArc.getIsFile()))
      System.out.println("Test: FAIL. The folder to be copied is a directory");
    else
      System.out.println("Test: PASS. The folder to be copied is not a directory");
  }

  @Test
  public void manyCharTest() throws IOException
  {
    Random random = new Random();

    int size1 = random.nextInt(10);
    String fileTest1 = String.valueOf(random.nextInt(10)) + ".txt";
    String content1 = "";

    for(int i = 0; i < size1; i++)
    {
      int con = random.nextInt(10);
      content1 += String.valueOf(con);
    }

    String destination1 = path + fileTest1;

    writeInputFile(destination1, content1);

    System.out.println("The file: " + fileTest1 + " contain " + size1 + " characters. Content: " + content1);
  }

  @Test
  public void contentTest() throws IOException
  {
    FileReader input = null;

    input = new FileReader(path + "blee.tar");

    boolean flag = false;
    int c;
    char m;
    while((c = input.read()) != -1)
    {
      m = (char)c;
      if(m == ' ' || m == '\n')
      {
        flag = true;
        break;
      }
    }

    if(flag)
      System.out.println("Tars contains characters such as spaces and line endings");
    else
      System.out.println("Tars DOES NOT contain spaces and/or line endings");
  }

  @Test
  public void numberOfArgumentsTest() throws IOException
  {
    Random random = new Random();

    int amount1 = random.nextInt(100);
    int amount2 = random.nextInt(100);
    String files1 = "start1.txt";
    String files2 = "start2.txt";
    String con = "";

    for(int i = 0; i < amount1; i++)
    {
      con = String.valueOf(random.nextInt(100));
      files1 += File.separator;
      files1 += ("file" + con + ".txt");
    }

    for(int i = 0; i < amount2; i++)
    {
      con = String.valueOf(random.nextInt(100));
      files2 += File.separator;
      files2 += ("file" + con + ".txt");
    }
    String[] args1 = {path + files1};
    String[] args2 = {path + files2};

    if(amount1 != amount2)
    {
      System.out.println("Passed wrong amount of arguments." + "Amount File1 = " + amount1 + ". Amount File2 = " + amount2);
      System.out.println("Wrong amount. Path args1: " + args1);
      System.out.println("Wrong amount. Path args2: " + args2);
    }
    else
      System.out.println("Passed correct amount of arguments");
  }

  public void writeInputFile(String file, String text) throws IOException
  {
    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
    writer.write(text);
    writer.close();
  }

  @Test
  public void fileNameCharTest() throws IOException
  {
    BinaryIn in = null;
    char sep =  (char) 255;
    in = new BinaryIn(path + "blee.tar");

    int filenamesize = in.readInt();
    sep = in.readChar();
    String filename="";
    for(int i = 0; i < filenamesize; i++)
      filename += in.readChar();

    if(filenamesize < 99) //The maximum length of a file name is limited to 99 characters.
      System.out.println("The file name: " + filename + " has less than 99 characters.");
    else
      System.out.println("The file name: " + filename + " has more than 99 characters.");
  }

}
